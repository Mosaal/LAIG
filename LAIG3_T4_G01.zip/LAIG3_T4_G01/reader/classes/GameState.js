function GameState(gsm, scene) {
	this.gsm = gsm;
	this.scene = scene;
}